package com.bootstrapdojo.web;
import org.springframework.roo.addon.web.mvc.thymeleaf.annotations.RooThymeleafMainController;

/**
 * = MainController
 *
 * TODO Auto-generated class documentation
 *
 */
@RooThymeleafMainController
public class MainController {
}

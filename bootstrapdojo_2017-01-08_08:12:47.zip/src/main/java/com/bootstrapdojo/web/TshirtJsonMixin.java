package com.bootstrapdojo.web;
import com.bootstrapdojo.domain.Tshirt;
import org.springframework.roo.addon.web.mvc.controller.annotations.config.RooJsonMixin;

/**
 * = TshirtJsonMixin
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJsonMixin(entity = Tshirt.class)
public abstract class TshirtJsonMixin {
}

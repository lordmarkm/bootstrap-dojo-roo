package com.bootstrapdojo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * = BootstrapdojoApplication
 *
 * TODO Auto-generated class documentation
 *
 */
@SpringBootApplication
public class BootstrapdojoApplication {

    /**
     * TODO Auto-generated method documentation
     *
     * @param args
     */
    public static void main(String[] args) {
        SpringApplication.run(BootstrapdojoApplication.class, args);
    }
}
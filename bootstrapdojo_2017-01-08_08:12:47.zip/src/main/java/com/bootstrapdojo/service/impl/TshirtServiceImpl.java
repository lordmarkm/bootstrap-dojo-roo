package com.bootstrapdojo.service.impl;
import com.bootstrapdojo.service.api.TshirtService;
import org.springframework.roo.addon.layers.service.annotations.RooServiceImpl;

/**
 * = TshirtServiceImpl
 *
 * TODO Auto-generated class documentation
 *
 */
@RooServiceImpl(service = TshirtService.class)
public class TshirtServiceImpl {
}

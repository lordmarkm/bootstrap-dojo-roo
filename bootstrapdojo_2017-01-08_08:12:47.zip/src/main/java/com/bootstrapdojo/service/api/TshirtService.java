package com.bootstrapdojo.service.api;
import com.bootstrapdojo.domain.Tshirt;
import org.springframework.roo.addon.layers.service.annotations.RooService;

/**
 * = TshirtService
 *
 * TODO Auto-generated class documentation
 *
 */
@RooService(entity = Tshirt.class)
public interface TshirtService {
}

package com.bootstrapdojo.repository;
import com.bootstrapdojo.domain.Tshirt;
import org.springframework.roo.addon.layers.repository.jpa.annotations.RooJpaRepository;

/**
 * = TshirtRepository
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJpaRepository(entity = Tshirt.class)
public interface TshirtRepository {
}

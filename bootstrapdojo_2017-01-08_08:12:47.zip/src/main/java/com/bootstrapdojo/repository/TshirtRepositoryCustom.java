package com.bootstrapdojo.repository;
import com.bootstrapdojo.domain.Tshirt;
import org.springframework.roo.addon.layers.repository.jpa.annotations.RooJpaRepositoryCustom;

/**
 * = TshirtRepositoryCustom
 *
 * TODO Auto-generated class documentation
 *
 */
@RooJpaRepositoryCustom(entity = Tshirt.class)
public interface TshirtRepositoryCustom {
}
